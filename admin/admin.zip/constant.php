<?php
define('dbserver', "localhost");
define('dbuser', "root");
define('dbpass', "");
define('dbname', "publisher");
define('base_url','http://'.$_SERVER['HTTP_HOST'].'/publisher.in/');
?>