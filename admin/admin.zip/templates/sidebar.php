<style type="text/css">
.sidebarbg
{
  background-color:#6366D9  ;
  margin: 5px ;
}
.smenu
{ 
   background-color:#8C8CB9  ;
  border-left:6px solid white;
}
</style><!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4 sidebarbg">
  <!-- Brand Logo -->
  <a href="dashboard" class="brand-link">
    publisher<span class="brand-text font-weight-light"></span>
  </a>

  <!-- Sidebar -->
  <div class="sidebar  sidebarbg">
    <!-- Sidebar Menu -->
    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <li class="nav-item smenu">
          <a href="dashboard" class="nav-link <?php echo (isset($active_tab) && trim($active_tab) == 'dashboard' ) ? 'active': ''; ?>">
            <i class="nav-icon fas fa-tachometer-alt"></i>
            <p>
              Dashboard
            </p>
          </a>
        </li>
        <!-----order managemnet------------------->

        <li class="nav-item has-treeview <?php echo (isset($active_tab) && trim($active_tab) == 'orders' ) ? 'menu-open': ''; ?>">
          <a href="#" class="nav-link <?php echo (isset($active_tab) && trim($active_tab) == 'orders' ) ? 'active': ''; ?>">
            <i class="nav-icon fas fa-shopping-basket"></i>
            <p>
              Order Management
              <i class="fas fa-angle-left right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="new-orders" class="nav-link <?php echo (isset($active_sub_tab) && trim($active_sub_tab) == 'new orders' ) ? 'active': ''; ?>">
                <i class="fas fa-cart-plus nav-icon"></i>
                <p>New Orders</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="pending-orders" class="nav-link <?php echo (isset($active_sub_tab) && trim($active_sub_tab) == 'pending orders' ) ? 'active': ''; ?>">
                <i class="fas fa-cart-arrow-down nav-icon"></i>
                <p>Pending Orders</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="delivered-orders" class="nav-link <?php echo (isset($active_sub_tab) && trim($active_sub_tab) == 'delivered orders' ) ? 'active': ''; ?>">
                <i class="fas fa-luggage-cart nav-icon"></i>
                <p>Delivered Orders</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="orders" class="nav-link <?php echo (isset($active_sub_tab) && trim($active_sub_tab) == 'orders' ) ? 'active': ''; ?>">
                <i class="fas fa-shopping-cart nav-icon"></i>
                <p>All Orders</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="export-orders" class="nav-link <?php echo (isset($active_sub_tab) && trim($active_sub_tab) == 'export orders' ) ? 'active': ''; ?>">
                <i class="fas fa-file-export nav-icon"></i>
                <p>Export Orders</p>
              </a>
            </li>
          </ul>
        </li>
         <!---- end order managemnet------------------->
             
       <!----- books managemnet------------------->
        <li class="nav-item has-treeview <?php echo (isset($active_tab) && trim($active_tab) == 'Books Management' ) ? 'menu-open': ''; ?>">
          <a href="#" class="nav-link <?php echo (isset($active_tab) && trim($active_tab) == 'products' ) ? 'active': ''; ?>">
            <i class="fa fa-book" aria-hidden="true"></i>
            <p>
            Books Management
              <i class="fas fa-angle-left right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="books" class="nav-link <?php echo (isset($active_sub_tab) && trim($active_sub_tab) == 'Books' ) ? 'active': ''; ?>">
               <i class="fa fa-book" aria-hidden="true"></i>
                <p>Books</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="book-category" class="nav-link <?php echo (isset($active_sub_tab) && trim($active_sub_tab) == 'Books Category' ) ? 'active': ''; ?>">
               <i class="fa fa-book" aria-hidden="true"></i>
                <p>Books Category</p>
              </a>
            </li>
          </ul>
            
 <!-----oend books managemnet------------------->
  <!-----Journals managemnet------------------->
        <li class="nav-item has-treeview <?php echo (isset($active_tab) && trim($active_tab) == 'gallery' ) ? 'menu-open': ''; ?>">
          <a href="#" class="nav-link <?php echo (isset($active_tab) && trim($active_tab) == 'Journal Management' ) ? 'active': ''; ?>">
            <i class="fas fa-photo-video nav-icon"></i>
            <p>
              Journal Management
              <i class="fas fa-angle-left right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="journal" class="nav-link <?php echo (isset($active_sub_tab) && trim($active_sub_tab) == 'Journals' ) ? 'active': ''; ?>">
                <i class="fas fa-cart-plus nav-icon"></i>
                <p>Journals</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="j-type" class="nav-link <?php echo (isset($active_sub_tab) && trim($active_sub_tab) == 'Journal Types' ) ? 'active': ''; ?>">
                <i class="fas fa-cart-arrow-down nav-icon"></i>
                <p>Journal Types</p>
              </a>
            </li>
          </ul>
        </li>
<!----- end Journals managemnet------------------->
<!-----Journals managemnet------------------->
         <div class="sidebarbg smenu">
         <li class="nav-item has-treeview <?php echo (isset($active_tab) && trim($active_tab) == 'gallery' ) ? 'menu-open': ''; ?>">
          <a href="#" class="nav-link <?php echo (isset($active_tab) && trim($active_tab) == 'Chapter Management' ) ? 'active': ''; ?>">
           <i class="fa fa-list-alt" aria-hidden="true"></i>
            <p>
              Chapter Management
              <i class="fas fa-angle-left right"></i>
            </p>
          </a>
         
          <ul class="nav nav-treeview">
           <div class="sidebarbg smenu">
            <li class="nav-item">
              <a href="chapter" class="nav-link <?php echo (isset($active_sub_tab) && trim($active_sub_tab) == 'Chapters' ) ? 'active': ''; ?>">
                <i class="fa fa-list-alt" aria-hidden="true"></i>
                <p>Chapters</p>
              </a>
            </li>
          </div>
            <div class="sidebarbg smenu">
            <li class="nav-item">
              <a href="domain" class="nav-link <?php echo (isset($active_sub_tab) && trim($active_sub_tab) == 'Domain Types' ) ? 'active': ''; ?>">
                  <i class="fa fa-list-alt" aria-hidden="true"></i>
                <p>Domain Types</p>
              </a>
            </li>
          </div>
          </ul>
        </li>
      </div>
        <div class="sidebarbg smenu">
         <li class="nav-item">
          <a href=" authors" class="nav-link <?php echo (isset($active_tab) && trim($active_tab) == ' Authors' ) ? 'active': ''; ?>">
            <i class="far fa-images nav-icon"></i>
            <p>
             Authors
            </p>
          </a>
        </li>
      </div>
        <div class="sidebarbg smenu">
         <li class="nav-item">
          <a href="editorials" class="nav-link <?php echo (isset($active_tab) && trim($active_tab) == 'Editorials' ) ? 'active': ''; ?>">
            <i class="far fa-images nav-icon"></i>
            <p>
              Editorials
            </p>
          </a>
        </li>
      </div>
     <div class="sidebarbg smenu">
        <li class="nav-item">
          <a href=" services" class="nav-link <?php echo (isset($active_tab) && trim($active_tab) == ' Services' ) ? 'active': ''; ?>">
            <i class="far fa-images nav-icon"></i>
          
            Services
          </a>
        </li>
      </div>
      <div class="sidebarbg smenu">
        <li class="nav-item">
          <a href="users" class="nav-link <?php echo (isset($active_tab) && trim($active_tab) == 'users' ) ? 'active': ''; ?>">
            <i class="fas fa-users nav-icon"></i>
            <p>
              Users
            </p>
          </a>
        </li>
        </div>
        <div class=" sidebarbg smenu">
        <li class="nav-item">
          <a href="about-us" class="nav-link <?php echo (isset($active_tab) && trim($active_tab) == 'about us' ) ? 'active': ''; ?>">
            <i class="far fa-address-card nav-icon"></i>
            <p>
              About Us
            </p>
          </a>
        </li>
      </div>
      <div class="sidebarbg smenu">
        <li class="nav-item">
          <a href="privacy-policy" class="nav-link <?php echo (isset($active_tab) && trim($active_tab) == 'privacy policy' ) ? 'active': ''; ?>">
            <i class="fas fa-user-lock nav-icon"></i>
            <p>
              Privacy Policy
            </p>
          </a>
        </li>
       </div>
       <div class="sidebarbg smenu">
        <li class="nav-item">
          <a href="terms-and-conditions" class="nav-link <?php echo (isset($active_tab) && trim($active_tab) == 'terms and conditions' ) ? 'active': ''; ?>">
            <i class="fas fa-gavel nav-icon"></i>
            <p>
              Terms & Condition
            </p>
          </a>
        </li>
      </div>
      <div class="sidebarbg smenu">
        <li class="nav-item">
          <a href="offer-and-discounts" class="nav-link <?php echo (isset($active_tab) && trim($active_tab) == 'special offers' ) ? 'active': ''; ?>">
            <i class="fas fa-percent nav-icon"></i>
            <p>
              Offers & Discounts
            </p>
          </a>
        </li>
        </div>
        <div class="sidebarbg smenu">
        <li class="nav-item">
          <a href="contact-request" class="nav-link <?php echo (isset($active_tab) && trim($active_tab) == 'contact request' ) ? 'active': ''; ?>">
            <i class="fas fa-phone-volume nav-icon"></i>
            <p>
              Contact Request
            </p>
          </a>
        </li>
      </div>
      </ul>
    </nav>
    <!-- /.sidebar-menu -->
  </div>
  <!-- /.sidebar -->
</aside>
<div class="content-wrapper">